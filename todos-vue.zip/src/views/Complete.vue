<template>
  <todo-list :todoList="completeTodo"/>
</template>
<script>
  import TodoList from "../components/TodoList";

  export default {
    name: "Complete",
    components: {TodoList},
    computed: {
      completeTodo() {
        return this.$store.getters.complete;
      }
    }
  }
</script>
