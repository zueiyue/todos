<template>
  <div>
    <todo-list :todoList="allTodo"/>
  </div>
</template>

<script>
    import TodoList from "../components/TodoList";
    export default {
        name: "All",
      components: {TodoList},
      computed:{
        allTodo (){
          return this.$store.getters.all
        }
      }
    }
</script>

<style scoped>
</style>
