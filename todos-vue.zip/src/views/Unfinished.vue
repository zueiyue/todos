<template>
  <todo-list :todoList="unfinishedTodo" />
</template>

<script>
    import TodoList from "../components/TodoList";
    export default {
        name: "Unfinished",
      components: {TodoList},
      computed:{
        unfinishedTodo(){
          return this.$store.getters.unfinished
        }
      }
    }
</script>

<style scoped>

</style>
