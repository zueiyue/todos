<template>
  <div id="app">
    <div class="todoapp">
      <Header style="margin-bottom: 5px"></Header>
      <router-view v-if="showFooter"></router-view>
      <Footer v-if="showFooter"></Footer>
    </div>
  </div>
</template>

<script>
import Footer from "./components/Footer";
import Header from "./components/Header";
export default {
  name: 'App',
  components: {Header, Footer},
  computed:{
    showFooter(){
      return this.$store.getters.all.length>0;
    }
  },
  data(){
    return {
      unit:''
    }
  }
}
</script>

<style>
#app {
  font: 14px 'Helvetica Neue', Helvetica, Arial, sans-serif;
  line-height: 1.4em;
  background: #f5f5f5;
  color: #4d4d4d;
  min-width: 230px;
  max-width: 550px;
  margin: 0 auto;
  text-align: center;
  border-bottom: 1px solid #e6e6e6;
  position: relative;
  top: 150px;
}
.todoapp {
  background: #fff;
  box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 25px 50px 0 rgba(0, 0, 0, 0.1);
}
</style>
