<template>
  <div id="button">
    <span class="count">{{item}} item {{count}} left</span>
    <router-link to="/all" tag="button" >all</router-link>
    <router-link to="/unfinished" tag="button">unfinished</router-link>
    <router-link to="/complete" tag="button">complete</router-link>
    <input v-if="showDelete" type="button" id="delete" @click="deleteCompleted" value="Clear completed"/>
  </div>
</template>

<script>
    export default {
        name: "Footer",
      computed:{
        item(){
          return this.$store.getters.unfinished.length;
        },
        count(){
          return this.$store.getters.all.length;
        },
        showDelete(){
          return this.$store.getters.complete.length>0;
        }
      },
      methods:{
        deleteCompleted(){
          this.$store.commit('delTodo');
        }
      }
    }
</script>

<style scoped>
  .count{
    float: left;
    text-align: left;
    color: #777;
    margin-left: 10px;
  }
  #button{
    padding-bottom: 10px;
    padding-top: 10px;
  }
  #button input,#button button{
    color: #777;
    background-color: #fff;
    border: 0;
  }
  #delete{
    float: right;
    margin-right: 10px;
  }
</style>
