<template>
  <div>
    <ul class="list" id="list">
      <li v-for="todo in todoList" @dblclick="dblClick(todo.id)" :key="todo.id">
        <div v-show="show.filter(s=>s.id===todo.id)[0].divShow">
          <input :checked="todo.complete" @change="check" :id="todo.id" type='checkbox'/>
          <span class='listText' :class="{delText:todo.complete}" :id="'title'+todo.id">{{todo.title}}</span>
          <button type='button' @click="delTodo(todo.id)" class='destroy'>X</button>
        </div>
        <input :id="'text'+todo.id" v-show="show.filter(s=>s.id===todo.id)[0].textShow"
               @keyup.enter="updateTodo(todo.id,$event)" @blur="blur(todo.id)" type='text'
               class='edit'/>
      </li>
    </ul>
  </div>
</template>

<script>
  export default {
    name: "TodoList",
    data() {
      return {
        show: []
      }
    },
    props: {
      todoList: Array
    },
    created() {
      let showArray = [];

      this.todoList.forEach(function (v, i) {
        showArray.push({id: v.id, divShow: true, textShow: false});
      });
      this.show = showArray;
    },
    beforeUpdate() {
      let showArray = [];
      let show = this.show;
      let todoList = this.todoList;
      let todos = [];
      todoList.forEach(function (v) {
        let bool = true;
        show.forEach(function (s) {
          if (v.id === s.id) {
            showArray.push(s);
            bool = false;
          }
        });
        if (bool) {
          todos.push(v)
        }
      });
      todos.forEach(function (value) {
        showArray.push({id: value.id, divShow: true, textShow: false})
      });
      this.show = showArray;
    },
    methods: {
      updateShow(showObject) {
        let updateShow = this.show;
        let j = -1;
        updateShow.forEach(function (v, i) {
          if (v.id === showObject.id) {
            j = i;
          }
        });
        this.show.splice(j, 1, showObject);
      },
      check(event) {
        let evn = event.target;
        this.$store.commit('updateTodo', {id: evn.id, complete: evn.checked})
      },
      delTodo(todoId) {
        this.$store.commit('delById', todoId)
      },
      dblClick(id) {
        this.updateShow({id: id, divShow: false, textShow: true});
        let title = this.todoList.filter(t => t.id === id)[0].title;
        this.$nextTick(function () {
          this.$el.querySelector('#text' + id).value = title;
          this.$el.querySelector('#text' + id).focus()
        });

      },
      blur(id) {
        this.updateShow({id: id, divShow: true, textShow: false});
      },
      updateTodo(id, event) {
        let evn = event.target;
        if (evn.value != null && evn.value !== "") {
          this.$store.commit('updateTodo', {id: id, title: evn.value});
          this.updateShow({id: id, divShow: true, textShow: false});
          this.$nextTick(function () {
            this.$el.querySelector('#title' + id).innerHTML = evn.value;
          })
        }
      }
    }
  }
</script>

<style scoped>
  .list {
    list-style: none;
    text-align: left;
    padding-left: 20px;
  }

  .listText {
    font-size: 30px;
    position: absolute;
    left: 80px;
    margin-top: 5px;
  }

  .delText {
    text-decoration: line-through;
    color: #d9d9d9;
  }

  #list input[type=checkbox] {
    width: 30px;
    height: 30px;
    -webkit-appearance: radio;
  }

  #list li {
    border-bottom: 1px solid #ededed;
    margin-bottom: 15px;
    margin-top: 15px;
  }

  #list li:hover .destroy {
    display: inline;
  }

  .destroy {
    display: none;
    float: right;
    width: 40px;
    border: 0;
    height: 40px;
    font-size: 30px;
    color: #cc9a9a;
    background-color: #FFF;
    margin-top: -10px;
  }

  .edit {
    width: 100%;
    font-size: 24px;
    line-height: 1.4em;
    padding: 6px;
    border: 1px solid #999;
    box-shadow: inset 0 -1px 5px 0 rgba(0, 0, 0, 0.2);
    box-sizing: border-box;
  }
</style>


