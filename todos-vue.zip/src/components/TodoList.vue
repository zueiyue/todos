<template>
  <div>
    <a-list id="list" bordered :dataSource="todoList">
      <a-list-item class="li"  slot="renderItem" slot-scope="item, index" v-if="show.filter(s=>s.id===item.id)[0].divShow" @dblclick="dblClick(item.id)">
        <a-list-item-meta style="margin-left: 0px">
        <a-checkbox slot="avatar" @change="check" :checked="item.complete" :value="item.id" :class="{delText:item.complete}" style="font-size: 24px">{{item.title}}</a-checkbox>
        </a-list-item-meta>
        <a-icon class="destroy" @click="delTodo(item.id)" type="close" />
      </a-list-item>
      <a-list-item slot="renderItem" slot-scope="item, index" v-else>
        <a-input :id="'text'+item.id" size="large" v-model="item.title" @pressEnter="updateTodo(item.id,$event)" @blur="blur(item.id)"/>
      </a-list-item>
    </a-list>
  </div>
</template>

<script>
  export default {
    name: "TodoList",
    data() {
      return {
        show: []
      }
    },
    props: {
      todoList: Array
    },
    created() {
      let showArray = [];

      this.todoList.forEach(function (v, i) {
        showArray.push({id: v.id, divShow: true, textShow: false});
      });
      this.show = showArray;
    },
    beforeUpdate() {
      let showArray = [];
      let show = this.show;
      let todoList = this.todoList;
      let todos = [];
      todoList.forEach(function (v) {
        let bool = true;
        show.forEach(function (s) {
          if (v.id === s.id) {
            showArray.push(s);
            bool = false;
          }
        });
        if (bool) {
          todos.push(v)
        }
      });
      todos.forEach(function (value) {
        showArray.push({id: value.id, divShow: true, textShow: false})
      });
      this.show = showArray;
    },
    methods: {
      updateShow(showObject) {
        let updateShow = this.show;
        let j = -1;
        updateShow.forEach(function (v, i) {
          if (v.id === showObject.id) {
            j = i;
          }
        });
        this.show.splice(j, 1, showObject);
      },
      check(checkedValues) {
        let evn = checkedValues.target;
        this.$store.commit('updateTodo', {id: evn.value, complete: evn.checked})
      },
      delTodo(todoId) {
        this.$store.commit('delById', todoId)
      },
      dblClick(id) {
        this.updateShow({id: id, divShow: false, textShow: true});
        let title = this.todoList.filter(t => t.id === id)[0].title;
        this.$nextTick(function () {
          this.$el.querySelector('#text' + id).focus()
        });
      },
      blur(id) {
        this.updateShow({id: id, divShow: true, textShow: false});
      },
      updateTodo(id, event) {
        let evn = event.target;
        if (evn.value != null && evn.value !== "") {
          this.$store.commit('updateTodo', {id: id, title: evn.value});
          this.updateShow({id: id, divShow: true, textShow: false});
        }
      }
    }
  }
</script>

<style scoped>
  .delText {
    text-decoration: line-through;
    color: #d9d9d9;
  }

  #list .li:hover .destroy {
    display: inline;
  }

  .destroy {
    display: none;
    color: #cc9a9a;
  }
</style>


