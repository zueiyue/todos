<template>
  <div>
    <h1 class="title">todos</h1>
    <a-input size="large" v-model="todo" @pressEnter="addTodo" placeholder="What needs to be done?">
      <a-button slot="addonBefore" @click="election"><a-icon type="down" /></a-button>
    </a-input>
<!--    <input type="text" @keyup.enter="addTodo" v-model="todo" placeholder="What needs to be done?" class="textInput"/>-->

  </div>
</template>

<script>
  import getUUID from "../assets/uuid";

  export default {
    name: "Header",
    data() {
      return {
        todo: '',
        checked: []
      }
    },
    methods: {
      addTodo() {
        if (this.todo == null || this.todo === '') {
          return
        }
        let v = {id: getUUID(), title: this.todo, complete: false};
        this.$store.commit('addTodo', v);
        this.todo = ''
      },
      election() {
        let path = this.$route.path.slice(1);
        if (path === '') {
          path = 'all';
        }
        let todoList=[];
        switch (path) {
          case 'all':
            todoList=this.$store.getters.all;
            break;
          case 'complete':
            todoList=this.$store.getters.complete;
            break;
          case 'unfinished':
            todoList=this.$store.getters.unfinished;
            break;
        }
        let bl=false;
        todoList.forEach(function(v){
          if(!v.complete){
            bl=true
          }
        });
        if(bl){
          this.$store.commit('selectAllTodo',true);
        }else{
          this.$store.commit('selectAllTodo',false);
        }
      },
    }
  }
</script>

<style scoped>
  .textInput {
    width: 85%;
    font-size: 24px;
    line-height: 1.4em;
    padding: 6px;
    border: 0px solid #999;
    border-radius: 10px;
    margin: 10px;
  }

  .election {
    width: 1.4em;
    height: 34px;
    font-size: 24px;
    border: 0;
    background-color: white;
    transform: rotate(90deg);
    margin-left: 10px;
  }

  .title {
    position: absolute;
    top: -90px;
    font-size: 70px;
    font-weight: 100;
    width: 550px;
    color: rgba(175, 47, 47, 0.5);
  }
</style>
