import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    todos: JSON.parse(localStorage.getItem("todos")) || []
  },
  mutations: {
    save(state) {
      localStorage.setItem("todos", JSON.stringify(state.todos));
    },
    addTodo(state, todo) {
      state.todos.push(todo);
      this.commit('save')
    },
    delTodo(state) {
      state.todos = state.todos.filter(todo => !todo.complete);
      this.commit('save')
    },
    delById(state, todoId) {
      state.todos = state.todos.filter(todo => !(todo.id === todoId));
      this.commit('save')
    },
    updateTodo(state, todo) {
      let j = -1;
      let newTodo = state.todos.filter(t => t.id === todo.id)[0];
      state.todos.forEach(function (v, i) {
        if (v.id === todo.id) {
          j = i;
          if (todo.complete != null) {
            Vue.set(newTodo, 'complete', todo.complete);
          }
          if (todo.title != null) {
            Vue.set(newTodo, 'title', todo.title);
          }
        }
      });
      Vue.set( state.todos,j,newTodo);
      this.commit('save');
    },
    selectAllTodo(state, check) {
      state.todos.forEach(todo => todo.complete = check);
      this.commit('save')
    }
  },
  getters: {
    complete: state => {
      return state.todos.filter(todo => todo.complete)
    },
    unfinished: state => {
      return state.todos.filter(todo => !todo.complete)
    },
    all: state => {
      return state.todos
    }
  }
})
