		window.todos={};
		todos.Model=function(){
			
			//添加
			this.addtodo=function(todo){
				//var test=[]
				var todos = localStorage.getItem("todos");
				var todosArray= JSON.parse(todos);
				if(todosArray==null){
					todosArray=[];
				}
				todo.id=uuid();
				todosArray.push(todo);
				localStorage.setItem("todos", JSON.stringify(todosArray));
			}
			
			//删除已完成
			this.del=function(){
				var todos = localStorage.getItem("todos");
				var todosArray= JSON.parse(todos);
				if(todosArray==null){
					todosArray=[];
				}
				var unfinished=[];
				todosArray.forEach(function(v,i){
					if(!v.completed){
						unfinished.push(v);
					}
				})
				localStorage.setItem("todos", JSON.stringify(unfinished));
			}
			
			//根据Id删除
			this.delById=function(id){
				var todosArray= JSON.parse(localStorage.getItem("todos"));
				if(todosArray==null){
					todosArray=[];
				}
				var todos=[];
				todosArray.forEach(function(v,i){
					if(v.id!=id){
						todos.push(v);
					}
				})
				localStorage.setItem("todos", JSON.stringify(todos));
			}
			
			//修改
			this.update=function(todo){
				var todos = localStorage.getItem("todos");
				var todosArray= JSON.parse(todos);
				if(todosArray==null){
					todosArray=[];
				}
				todosArray.forEach(function(v,i){
					if(v.id==todo.id){
						if(todo.title!=null){
							v.title=todo.title;
						}
						if(todo.completed!=null){
							v.completed=todo.completed;
						}
					}
				})
				localStorage.setItem("todos", JSON.stringify(todosArray));
			}
			
			//获取所有
			this.getTodos=function(){
				return JSON.parse(localStorage.getItem("todos"));
			}
			
			// 观察者模式 
			var self = this, 
		        views = [];
		
		    this.register = function(view) {
		        views.push(view);
		    };
		
		    this.notify = function(todos) {
		        for(var i = 0; i < views.length; i++) {
		            views[i].showList(todos);
		        }
		    };
		}

		todos.View=function(controller){
			var list=document.getElementById("list"),
				content=document.getElementById("content"),
				election=document.getElementById("election"),
				del=document.getElementById("delete"),
				unfinished=document.getElementById("unfinished"),
				completed=document.getElementById("completed"),
				all=document.getElementById("all"),
				button=document.getElementById("button"),
				count=document.getElementsByClassName("count")[0],
				delById=null,
				check=null;
				
				//显示列表
				this.showList=function(todos){
					var t= JSON.parse(localStorage.getItem("todos"));
					if(t!=null){
						if(t.length==0){
							button.style.display="none";
						}else{
							button.style.display="";
						}
						var bl=false;
						var j=0;
						t.forEach(function(v,i){
							if(v.completed){
								bl=true;
							}else{
								j++;
							}
						})
						if(j>1){
							count.innerHTML=j+" items "+t.length+" left"
						}else{
							count.innerHTML=j+" item "+t.length+" left"
						}
						
						if(bl){
							del.style.display="";
						}else{
							del.style.display="none";
						}
						
					}else{
						button.style.display="none";
						return;
					}
					
					if(todos==null){
						return
					}
					list.innerHTML="";
					todos.forEach(function(v,i){
						var li = document.createElement("li"); 
						if(v.completed){
							li.innerHTML="<div><input checked id='"+v.id+"' type='checkbox'/>"+"  <span class='listText delText'>"+v.title+"</span><button type='button' class='destroy' name='"+v.id+"'>X</button></div><input type='text' class='edit'/>";
						}else{
							li.innerHTML="<div><input id='"+v.id+"' type='checkbox'/>"+"  <span class='listText'>"+v.title+"</span><button type='button' class='destroy' name='"+v.id+"'>X</button></div><input type='text' class='edit'/>";
						}
						li.ondblclick=controller.dblclick;
						list.appendChild(li);
					})
					
					check=document.getElementById("list").getElementsByTagName("input");
					delById=document.getElementById("list").getElementsByClassName("destroy");
					for(var i=0;i<check.length;i++){
						if(check[i].type=="checkbox"){
							check[i].onchange=controller.check;
						}
					}
					
					for(var i=0;i<delById.length;i++){
						delById[i].onclick=controller.delById;
					}
				}
				//绑定事件
				all.onclick       =controller.showAll;
				unfinished.onclick=controller.showUnfinished;
				completed.onclick =controller.showCompleted;
				del.onclick       =controller.del;
				election.onclick  =controller.election;
				content.onkeydown = controller.keydown;
		}
		
		todos.Controller=function(){
			var model=null,
			 	view=null,
			 	controller=this;
			 	
			 var status=0;
			//初始化
		 	this.init = function() {
		        model = new todos.Model();
		        view = new todos.View(this);
		
		        model.register(view);
		        model.notify(model.getTodos());
	    	};
	    	
	    	//回车事件 添加
	    	this.keydown = function(event) {
	    		var evn=event.target;
	    		if (event.keyCode == "13") {
	    			if(evn.value!=null && evn.value!=""){
	    				model.addtodo({"title":evn.value,"completed":false})
		    			evn.value="";
		    			controller.showByStatus();
	    			}
			　　}
		    };
		    
			//change事件 修改选中状态
		    this.check=function(event){
		    	
		    	var evn=event.target;
		    	model.update({"id":evn.id,"completed":evn.checked})
		    	controller.showByStatus();
		    }
		    
		    //全选
		    this.election=function(event){
		    	var div = document.getElementById("list").getElementsByTagName("div");
		    	var bl=false;
		    	for(var i=0;i<div.length;i++){
					if(!div[i].getElementsByTagName("input")[0].checked){
						bl=true;
						break;
					}
				}
		    	var len= div.length;
		    	if(bl){
		    		for(var i=0;i<len;i++){
						div[len-i-1].getElementsByTagName("input")[0].checked=true;
						div[len-i-1].getElementsByTagName("input")[0].onchange({"target":{"id":div[len-i-1].getElementsByTagName("input")[0].id,"checked":true}});
					}
		    	}else{
		    		for(var i=0;i<len;i++){
						div[len-i-1].getElementsByTagName("input")[0].checked=false;
						div[len-i-1].getElementsByTagName("input")[0].onchange({"target":{"id":div[len-i-1].getElementsByTagName("input")[0].id,"checked":false}});
					}
		    	}
		    }
		    
		    //显示全部
		    this.showAll=function(event){
		    	//var evn= event.target;
		    	status=0
		    	var todosArray=model.getTodos();
		    	model.notify(todosArray);
		    }
		    
		    //显示未完成
		    this.showUnfinished=function(event){
		    	//var evn= event.target;
		    	var todosArray=model.getTodos();
		    	if(todosArray==null){
					todosArray=[];
				}
		    	var unfinished=[];
		    	todosArray.forEach(function(v,i){
		    		if(!v.completed){
		    			unfinished.push(v)
		    		}
		    	})
		    	status=1
		    	model.notify(unfinished);
		    }
		    //显示已完成
		    this.showCompleted=function(event){
		    	//var evn= event.target;
		    	var todosArray=model.getTodos();
		    	if(todosArray==null){
					todosArray=[];
				}
		    	var completed=[];
		    	todosArray.forEach(function(v,i){
		    		if(v.completed){
		    			completed.push(v)
		    		}
		    	})
		    	status=-1
		    	model.notify(completed);
		    }
		    //清除已完成
		    this.del=function(event){
		    	var evn= event.target;
				model.del();
				controller.showByStatus();
		    }
		    //根据id删除
		    this.delById=function(event){
		    	var evn=event.target;
		    	model.delById(evn.name);
		    	controller.showByStatus();
		    }
		    //根据当前状态显示列表  1显示未完成 0显示全部-1显示已完成
		    this.showByStatus=function(){
		    	switch(status){
		    		case 1: 
		    		controller.showUnfinished();
		    		break;
		    		case 0: 
		    		controller.showAll();
		    		break;
		    		case -1: 
		    		controller.showCompleted();
		    		break;
		    	}
		    }
		    
		    //双击修改内容
		    this.dblclick=function(event){
		    	var div=this.getElementsByTagName("div")[0];
		    	var edit=this.getElementsByClassName("edit")[0];
		    	var text=div.getElementsByTagName("span")[0].innerHTML;
		    	var id=div.getElementsByTagName("input")[0].id;
		    	div.style.display="none";
		    	edit.style.display="inline";
		    	edit.value=text;
		    	edit.focus();
		    	edit.onblur=function(){
		    		div.style.display="inline";
		    		edit.style.display="none";
		    	}
		    	edit.onkeydown=function(event){
		    		var evn=event.target;
		    		if (event.keyCode == "13") {
		    			if(evn.value!=null && evn.value!=""){
		    				model.update({"id":id,"title":edit.value});
		    				controller.showByStatus();
		    			}
				　　 }
		    	}
		    }
		}
		
		//生成id
		window.uuid=function () {
	        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
	            var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
	            return v.toString(16);
	        })
   		}